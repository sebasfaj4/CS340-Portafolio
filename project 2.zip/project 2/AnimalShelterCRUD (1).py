from pymongo import MongoClient
from pymongo.errors import PyMongoError


class AnimalShelterCRUD:
    """CRUD operations for the AAC MongoDB database."""

    def __init__(self, username, password):
        """Connect to MongoDB using authentication."""
        try:
            uri = f"mongodb://{username}:{password}@127.0.0.1:27017/aac?authSource=admin"
            self.client = MongoClient(uri)
            self.database = self.client["aac"]
            self.collection = self.database["animals"]
        except PyMongoError as e:
            print(f"Connection error: {e}")

    def create(self, data):
        """Insert a document. Return True if successful, else False."""
        if data is None or not isinstance(data, dict) or len(data) == 0:
            return False
        try:
            result = self.collection.insert_one(data)
            return result.acknowledged
        except PyMongoError as e:
            print(f"Create error: {e}")
            return False

    def read(self, query):
        """Find documents using find(). Return list of documents, else empty list."""
        if query is None or not isinstance(query, dict):
            return []
        try:
            cursor = self.collection.find(query)
            return list(cursor)
        except PyMongoError as e:
            print(f"Read error: {e}")
            return []

    def update(self, query, update_data, many=False):
        """
        Update document(s).
        update_data must be valid for update_one/update_many (example: {"$set": {...}})
        Return number of modified documents.
        """
        if query is None or not isinstance(query, dict):
            return 0
        if update_data is None or not isinstance(update_data, dict) or len(update_data) == 0:
            return 0

        try:
            if many:
                result = self.collection.update_many(query, update_data)
            else:
                result = self.collection.update_one(query, update_data)
            return int(result.modified_count)
        except PyMongoError as e:
            print(f"Update error: {e}")
            return 0

    def delete(self, query, many=False):
        """Delete document(s). Return number of deleted documents."""
        if query is None or not isinstance(query, dict):
            return 0
        try:
            if many:
                result = self.collection.delete_many(query)
            else:
                result = self.collection.delete_one(query)
            return int(result.deleted_count)
        except PyMongoError as e:
            print(f"Delete error: {e}")
            return 0
